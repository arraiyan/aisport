from cSRC.inf import env as ENV
from cSRC.db import loadDB , saveDB
loadDB()
def add_new_field_to_user(number,field,value):
    for user_id,user in ENV.DataBase['users'].items():
        ENV.DataBase['users'][user_id][field]=value
        saveDB()
def remove_fields(filed,data):
    for user_id , user in ENV.DataBase['users'].items():
        for d in user[filed]:
            if d == data:
                user[filed].remove(d)
                print('removed')
                saveDB()

# ENV.DataBase['super_admin_id'] = []
# ENV.DataBase['admins'] = []
# saveDB()
# # add_new_field_to_user(1,'reinvest',float(0.00))
# # loadDB()
# # print(ENV.DataBase['users'])
# remove_fields('down_stream',None)
# print(ENV.DataBase['users'])

# ENV.DataBase['winning_system_wide']=[0]
for user_id,user in ENV.DataBase['users'].items():
    if not user_id == 'user_id':
        ENV.DataBase['users'][user_id]['investments'].pop('total_invested')
        print('\n\n')
        saveDB()


