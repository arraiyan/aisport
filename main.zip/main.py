import logging

from telegram import __version__ as TG_VER

try:
    from telegram import __version_info__
except ImportError:
    __version_info__ = (0, 0, 0, 0, 0)  # type: ignore[assignment]

if __version_info__ < (20, 0, 0, "alpha", 1):
    raise RuntimeError(
        f"This example is not compatible with your current PTB version {TG_VER}. To view the "
        f"{TG_VER} version of this example, "
        f"visit https://docs.python-telegram-bot.org/en/v{TG_VER}/examples.html"
    )
from telegram import *
from telegram.ext import *
from cSRC.inf import env as ENV
from cSRC.db import saveDB,loadDB
from datetime import datetime 
import re
import os
import uuid
import qrcode
from random import randint
from nowpayments import NOWPayments
from cSRC.payments import minimum_amount , confirm_payment , new_payment ,get_current_btc_price
from datetime import datetime as dt
import pandas as pd
from datetime import timedelta
import pyotp
import math
loadDB()
#LOAD DATABASE 

# Enable logging
logging.basicConfig(
    format="%(asctime)s - %(name)s - %(levelname)s - %(message)s", level=logging.INFO
)
logger = logging.getLogger(__name__)
HTML = "HTML"

# Define a few command handlers. These usually take the two arguments update and
# context.

KeyBoard = [
            ['📥/BuyIn','📤/PayOut','👥/RewardPlan'],
            ['✉ FAQ','💰/Balance','🔒/Activate2FA'],
            ['💳/Fees','📋/About','❓/Support'],
            ['/Withdraw']
        ]
async def start(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    if update.message.chat.type == 'private':
        user = update.effective_user
        if user.username == None:
            await update.message.reply_text("Go to you Telegram Account settings and create and Create an user name first . Then retry")
            return
        if not user.username in ENV.DataBase['user_name_id']:
            ENV.DataBase['user_name_id'][user.username] = user.id
            saveDB()
            
        if not user.id in ENV.DataBase['users']:
           # saves the newly created user
            text_recieved = update.message.text.split(' ')
            if len(text_recieved)>1:


                if(text_recieved[1].split('--')[0]=='reffered'):                
                    #ENV.DataBase['users'][user.id]
                    user_primar={
                        'reinvest':float(0.00),
                        'is_active':True,
                        'down_stream':[],
                        'level':0,
                        '2fa':{
                            'status':False,
                            'uuid':"",
                        },
                        'user_name':user.name, 'rank':0 , 'reffered_by': "" ,'sponsore_id':"",'balance_in_btc':float(0.00000),"blance_in_usdt":float(0.00),
                        'date_joined': str(datetime.now()),'balance_status':{
                            'pv':0.00,
                            'daily_bonus':0.00,
                            'total_returns':0.00,
                            'commissions':0.00,

                                'last_withdrawn':{
                                'date':"",
                                'amount_usdt':float(0.00), # usdt
                                'amount_btc':float(0.00000), # btc
                                'approved_by':""
                            },
                                'pending_withdrawal':{
                                'status':False,#when withdrawn it should be true 
                                'requested_at':"",
                                'amount_usd':float(0.00), # usdt
                            }
                        },
                        'bank_details':{
                            'btc':{
                                'wallet_adress':"",
                            }
                        },  
                        'investments':{
                            'total_invested_usd':0.00,
                            'last_invested_on':'date',
                            'all_transactions':[],
                        }, 
                        'refferal_link':""  ,
                        'payment_ids':[]          
                    }
                    reffer = None
                    try:
                        reffer = ENV.DataBase['user_name_id'][str(text_recieved[1].split('--')[1])]
                    except:
                        reffer = None
                    ac_o = False
                    #print(reffer)
                    if(str(text_recieved[1].split('--')[1])==ENV.DataBase['universal_uuid0']):
                        #print('universal user')
                        ac_o = True
                        ENV.DataBase['users'][user.id] = user_primar
                        saveDB()

                    elif reffer == None and ac_o == False:
                        await update.message.reply_text("The Sponsor username not found tell you sponsore to give the link properly . or if he have changed his user name recently tell him to type /start in the bot that will update his data")
                        return
                    # #print()
                    elif ac_o == False and not reffer == None:
                        ENV.DataBase['users'][user.id] = user_primar
                        saveDB()
                        ##print('user created')
                        reffer=ENV.DataBase['user_name_id'][(str(text_recieved[1].split('--')[1]))]
                        reffer_user_name =  str(text_recieved[1].split('--')[1])                         
                        ENV.DataBase['users'][int(reffer)]['down_stream'].append(user.username)
                        ENV.DataBase['users'][user.id]['reffered_by'] = reffer
                        ENV.DataBase['users'][user.id]['sponsore_id'] = reffer
                        ENV.DataBase['users'][user.id]['refferal_link'] = "https://t.me/aisportsbook_bot?start=reffered--"+str(reffer)
                        
                        saveDB()
                        #print('app 2')
                else:
                    #print("no answer")
                    return
            else:
                await update.message.reply_text('You need a sponsor to continue.Ask your sponsore for the referral link')
                return
            
            

        reply_markup = ReplyKeyboardMarkup(KeyBoard)
        await update.message.reply_chat_action(action=constants.ChatAction.TYPING)
        await update.message.reply_html(
            rf"{user.mention_html()}"+ENV.DataBase['starttext'],
            reply_markup= reply_markup
        )
    

async def about(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    await update.message.reply_chat_action(action=constants.ChatAction.TYPING)

    await update.message.reply_text(ENV.DataBase['abouttext'],parse_mode=HTML)

async def support(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    await update.message.reply_chat_action(action=constants.ChatAction.TYPING)
    user = update.effective_user
    sponsore = ENV.DataBase['users'][user.id]['reffered_by']
    if type(sponsore) == type(str()):
        try:
            sponsore = ENV.DataBase['user_name_id'][sponsore]
            sponsore = ENV.DataBase['users'][int(sponsore)]['user_name']
        except:
            sponsore='No Sponsor found'
    else:
        sponsore = ENV.DataBase['users'][int(sponsore)]['user_name']
    await update.message.reply_text(f"""
❓Support at AISPORTSBOOK
📌 If you have any questions or support regarding the Projektname, please contact your sponsor. Your sponsor is
󰞵 {sponsore}
✉ If your sponsor cannot answer your questions, you can also contact our support via email with subject
account number #{user.id} - support@aisportsbook.freshdesk.com
    """,parse_mode=HTML)

async def faq(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    await update.message.reply_chat_action(action=constants.ChatAction.TYPING)
    await update.message.reply_text(ENV.DataBase['faqtext'],parse_mode=HTML)


def calculate_rank(user_id) -> None:
    rank = "Member"

    
    user_data = ENV.DataBase['users'][int(user_id)]
    direct_members = user_data.get("down_stream", [])
    new_members = []
    #print(direct_members)
    for m in direct_members :
        try:
            new_members.append(ENV.DataBase['user_name_id'][m]) 
        except:
            pass
    direct_members = new_members
    team_volume = float(ENV.DataBase['users'][int(user_id)]['balance_status']['pv'])#user_data.get("team_volume", 0.00)
    users = ENV.DataBase['users']
    personal_volume = user_data["balance_status"]["pv"]
    team_volume = personal_volume + sum(users[member]["balance_status"]["pv"] for member in direct_members)
    # personal_volume + sum(users[member]["balance_status"]["pv"] for member in direct_members)
    if len(direct_members) >= 5 and team_volume >= 5000.00 and personal_volume >= 100.00 and all(users[member]["balance_status"]["pv"] >= 100.00 for member in direct_members):
        rank = "Bronze"
    if rank == "Bronze" and len([member for member in direct_members if calculate_rank(member) == "Bronze"]) >= 5 and team_volume >= 25000.00:
        rank = "Silver"
    if rank == "Silver" and len([member for member in direct_members if calculate_rank(member) == "Silver"]) >= 5 and team_volume >= 150000.00:
        rank = "Gold"
    if rank == "Gold" and len([member for member in direct_members if calculate_rank(member) == "Gold"]) >= 5 and team_volume >= 1000000.00:
        rank = "Onyx"
    if rank == "Onyx" and len([member for member in direct_members if calculate_rank(member) == "Onyx"]) >= 5 and team_volume >= 5000000.00:
        rank = "Pearl"
    if rank == "Pearl" and len([member for member in direct_members if calculate_rank(member) == "Pearl"]) >= 5 and team_volume >= 25000000.00:
        rank = "Diamond"
    if rank == "Diamond" and len([member for member in direct_members if calculate_rank(member) == "Diamond"]) >= 5 and team_volume >= 100000000.00:
        rank = "Ammolite"

    return rank


async def rewardplan(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    await update.message.reply_chat_action(action=constants.ChatAction.TYPING)
    user = update.effective_user
    user_data = ENV.DataBase['users'][user.id]
    ENV.DataBase['users'][user.id]['level'] = count_level(float(ENV.DataBase['users'][user.id]['balance_status']['pv']))
    saveDB()
    level = int(user_data['level'])
    #print(level)
    if level < 1:
        await update.message.reply_text(ENV.DataBase['rewardplantext'],parse_mode=HTML)
    elif level >= 1 :
        ENV.DataBase['users'][user.id]['is_active']=True
        saveDB()
        pv = round(ENV.DataBase['users'][user.id]['balance_status']['pv'],2)
        total_returns =round(ENV.DataBase['users'][user.id]['balance_status']['total_returns'],2) 
        commissions = ENV.DataBase['users'][user.id]['balance_status']['commissions']
        total_invested_usd = ENV.DataBase['users'][user.id]['investments']['total_invested_usd']
        downline_text = "Your Downline"

        for user_ in ENV.DataBase['users'][user.id]['down_stream']:
            u_pv = round(ENV.DataBase['users'][int(ENV.DataBase['user_name_id'][user_])]['investments']['total_invested_usd'],2) 
            u_active = ENV.DataBase['users'][int(ENV.DataBase['user_name_id'][user_])]['is_active']
            if u_active:
                downline_text = downline_text + '\n' + '@'+str(user_) + f'(PV : {u_pv} USD)' 

        rank = calculate_rank(user.id)
        # try:
        #     rank = calculate_rank(user.id)
        # except:
        #     rank = "Member"
        text_to_send1=f"""
Your Balance is {pv}
Own turnover: {total_returns} USD
You Rank : {rank}
{user.first_name},Your sponsor name is {user.username}
💤 Partners who have been inactive for 30 days will be hidden. You can show all partners: /showinactive
        """
        bot_data = await context.bot.get_me()
        text_to_send2 = f"""
👥 Reward Plan
If you recommend AISPORTSBOOK, you will receive the following commissions:
30% based on the daily reported income is distributed up to 10 levels deep.
01st level - 10% (minimum deposit 100 USD)
02nd level - 5.0% (minimum deposit 150 USD)
03rd level - 2.5% (minimum deposit $250)
04th level - 2.5% (minimum deposit 500 USD)
05th level - 2.5% (minimum deposit $1,000)
06th level - 2.5% (minimum deposit $2,000)
07th Level - 2.0% (minimum deposit $4,000)
08th Level - 1.0% (minimum deposit $6,000)
09th Level - 1.0% (minimum deposit $7,500)
10th level - 1.0% (minimum deposit $10,000)
There is also a lifestyle bonus:
🥉Bronze one-time 250 USD bonus (min. 5 direct members with a total of 5,000.00 USD own turnover)
🥈Silver monthly 500 USD bonus (min. 5 direct bronze + 25,000.00 USD team volume)🥇
🥇Gold monthly 2,000 USD bonus (min. 5 direct Silver + 150,000.00 USD team volume)
󰥔 Onyx monthly 10,000 USD bonus (min. 5 direct gold + 1,000,000.00 USD team volume)
🦪Pearl monthly $20,000 bonus (min. 5 direct Onyx + $5,000,000.00 team volume)
💎Diamond monthly $30,000 bonus (min. 5 direct Pearl + $25,000,000.00 team volume)
🎯Ammolite monthly $50,000 bonus (min. 5 direct Diamonds + $100,000,000.00 team volume)
Send the following link to your friends or partners and they will be subscribed to AISPORTSBOOK under you:
{downline_text}
https://t.me/{bot_data.username}?start=reffered--{user.username}
        """
        await update.message.reply_text(text_to_send1,parse_mode=HTML)
        await update.message.reply_text(text_to_send2,parse_mode=HTML)

async def addWallet(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    await update.message.reply_chat_action(action=constants.ChatAction.TYPING)  
    user= update.effective_user  
    if update.message.chat.type == "private":
        address = update.message.text.replace('/addWallet','').replace(' ','')
        ENV.DataBase['users'][user.id]['bank_details']['btc']['wallet_adress'] = address
        #print(address)
        await update.message.reply_text(ENV.DataBase['addwallettext'] + f"\nWallet <code>{address}</code>",parse_mode=HTML)

async def dipositTo(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    await update.message.reply_chat_action(action=constants.ChatAction.TYPING)
    if update.message.chat.type == 'private':
        account_address = update.message.text.replace('/dipositTo','').replace('\n','').replace(' ','')
        await update.message.reply_text(f'updated the diposit address to \n<code>{account_address}</code>',parse_mode=HTML)

async def BuyIn(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    await update.message.reply_chat_action(action=constants.ChatAction.TYPING)
    if update.message.chat.type == 'private':
        await update.message.reply_text(ENV.DataBase['buyintext']+"""
To buy use /buy amount_in_usd command
<code>/buy [amount_in_usd]</code>
Example:
<code>/buy 100</code>
        """,parse_mode=HTML)
async def daily(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    #print('action')
    await update.message.reply_chat_action(action=constants.ChatAction.TYPING)
    
    user = update.effective_user
    #print(ENV.DataBase['admins'])
    if user.id in ENV.DataBase['admins'] or user.id in ENV.DataBase['super_admin_id']:
        commission = update.message.text.split(' ')[1]
        ENV.DataBase['daily_commission'] = float(commission)
        security = str(uuid.uuid1())[0:4]
        ENV.DataBase['daily_commission_security_key'] = security
        saveDB()
        await update.message.reply_text(f"You've requested a daily commission of {commission}%\n to initialize the action please use <code>/init daily {security}</code>",parse_mode=HTML)
        pass
async def commission(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    await update.message.reply_chat_action(action=constants.ChatAction.TYPING)
    user = update.effective_user
    #print(ENV.DataBase['admins'])
    if user.id in ENV.DataBase['admins'] or user.id in ENV.DataBase['super_admin_id']:
        commission = update.message.text.split(' ')[1]
        ENV.DataBase['commission'] = float(commission)
        security = str(uuid.uuid1())[0:4]
        ENV.DataBase['ommission_security_key'] = security
        saveDB()
        await update.message.reply_text(f"You've requested a commission of {commission}%\n to initialize the action please use <code>/init com {security}</code>",parse_mode=HTML)
        pass
async def monthly(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    await update.message.reply_chat_action(action=constants.ChatAction.TYPING)
    user = update.effective_user
    if user.id in ENV.DataBase['admins'] or user.id in ENV.DataBase['super_admin_id']:
        commission = update.message.text.split(' ')[1]
        ENV.DataBase['monthly_commission'] = float(commission)
        security = str(uuid.uuid1())[0:4]
        ENV.DataBase['monthly_commission_security_key'] = security
        saveDB()
        await update.message.reply_text(f"You've requested a monthly commission of {commission}%\n to initialize the action please use <code>/init monthly {security}</code>",parse_mode=HTML)
        pass


def des_commission(total_commission,user_id):
    breaker = 1
    if user_id == 'user_id':
        return
    while breaker <= 10 :
        user_min = ENV.DataBase['users'][user_id]
        
        referrer = (user_min['reffered_by'])
        if referrer == '':
            break
        if type(referrer) == type(str()):
            try:
                referrer = ENV.DataBase['user_name_id'][referrer]
            except:
                break
        #print(referrer)
        count_level(ENV.DataBase['users'][referrer]['balance_status']['pv'])
        reffer_level = ENV.DataBase['users'][int(referrer)]['level']
        percentages = {
            1: 10.0,
            2: 5.0,
            3: 2.5,
            4: 2.5,
            5: 2.5,
            6: 2.5,
            7: 2.0,
            8: 1.0,
            9: 1.0,
            10: 1.0
        }
        if reffer_level >= breaker:
            ENV.DataBase['users'][referrer]['balance_status']['pv'] = ENV.DataBase['users'][referrer]['balance_status']['pv'] + total_commission*percentages[breaker]/100 
            ENV.DataBase['users'][referrer]['balance_status']['commissions'] = ENV.DataBase['users'][referrer]['balance_status']['commissions'] + total_commission*percentages[breaker]/100 
            ENV.DataBase['users'][referrer]['reinvest'] = ENV.DataBase['users'][referrer]['reinvest'] + total_commission*percentages[breaker]/100 
            saveDB()

        user_id = referrer
        breaker += 1



def monthly_commissions(percent:float):
    if len(ENV.DataBase['winning_system_wide'])>=30:
        ENV.DataBase['winning_system_wide'].pop(0)
    ENV.DataBase['winning_system_wide'].append(percent) 
    saveDB()    
    percent = percent/100
    for key,user in ENV.DataBase['users'].items():
        if user['level'] > 0 and user['balance_status']['pv'] >= 50:
            commission = percent*user['balance_status']['pv']
            user['balance_status']['pv'] = percent*(user['balance_status']['pv']-user['reinvest'])
            user['reinvest'] = user['reinvest'] + commission
            user['balance_status']['total_returns'] = user['balance_status']['total_returns'] + commission
            des_commission(commission,key)
            saveDB()
def daily_commissions(percent:float):
    if len(ENV.DataBase['winning_system_wide'])>=30:
        ENV.DataBase['winning_system_wide'].pop(0)
    ENV.DataBase['winning_system_wide'].append(percent) 
    saveDB()
    percent = percent/100
    for key,user in ENV.DataBase['users'].items():
        if user['level'] > 0 and user['balance_status']['pv'] >= 50:
            commission = percent*(user['balance_status']['pv']-user['reinvest'])
            user['balance_status']['pv'] = user['balance_status']['pv'] + commission
            user['reinvest'] = user['reinvest'] + commission
            user['balance_status']['total_returns'] = user['balance_status']['total_returns'] + commission
            des_commission(commission,key)
            saveDB()
    
def commissions(percent:float):
    percent = percent/100
    for key,user in ENV.DataBase['users'].items():
        if user['level'] > 0 and user['balance_status']['pv'] >= 50:
            commission = percent*user['balance_status']['pv']
            user['balance_status']['pv'] = user['balance_status']['pv'] + commission
            user['balance_status']['total_returns'] = user['balance_status']['total_returns'] + commission
            user['balance_status']['commissions'] = user['balance_status']['commissions'] + commission
            saveDB()
def update_pv(number:float,user_id:int):
    user = ENV.DataBase['users'][user_id]
    ENV.DataBase['users'][user_id]['balance_status']['pv'] =user['balance_status']['pv'] + number
    ENV.DataBase['users'][user_id]['investments']['total_invested_usd'] =user['investments']['total_invested_usd'] + number
    ENV.DataBase['users'][user_id]['investments']['last_invested_on'] =str(dt.now())
    ENV.DataBase['users'][user_id]['level'] = count_level(float(ENV.DataBase['users'][user_id]['balance_status']['pv']))
    saveDB()    
async def init(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    await update.message.reply_chat_action(action=constants.ChatAction.TYPING)
    user = update.effective_user
    text = update.message.text
    if user.id in ENV.DataBase['admins'] or user.id in ENV.DataBase['super_admin_id']:
        command_type = text.split()[1]
        security = text.split()[2]
        if command_type == 'monthly':
            if security == ENV.DataBase['monthly_commission_security_key']:
                monthly_commissions(ENV.DataBase['monthly_commission'])
                ENV.DataBase['monthly_commission'] = float(0.00)
                saveDB()
        elif command_type == 'daily':
            if security == ENV.DataBase['daily_commission_security_key']:
                daily_commissions(ENV.DataBase['daily_commission'])
                ENV.DataBase['daily_commission'] = float(0.00)
                saveDB()
        elif command_type == 'com':
            if security == ENV.DataBase['commission_security_key']:
                commissions(float(ENV.DataBase['commission']))
                ENV.DataBase['commission'] = float(0.00)
                saveDB()            
    
        await update.message.reply_text(f"Your requested task was initialized",parse_mode=HTML)

    else :
        await update.message.reply_text("To initialize such actions you must login first")

async def buy(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    user = update.effective_user
    await update.message.reply_chat_action(action=constants.ChatAction.TYPING)
    if update.message.chat.type == 'private':
        if len(update.message.text.split()) == 2:
            amount = float(update.message.text.split()[1])
            minimum = minimum_amount()['fiat_equivalent']
            if amount<minimum :
                await update.message.reply_text("The amount requested is too low for transaction",parse_mode=HTML)
            else:
                payment = new_payment(amount)
                ENV.DataBase['users'][user.id]['payment_ids'].append(payment['payment_id'])
                saveDB()
                img = qrcode.make('bitcoin:'+payment['pay_address'])
                img_path = f"{str(randint(99999,999999))}.png"
                img.save(img_path)
                await context.bot.send_photo(update.message.chat_id,open(img_path,'rb'),caption=f"""

Pay Address : <code>{payment['pay_address']}</code>
Price Amount in USD : <code>{float(payment['price_amount'])}</code>
Price Amount in BTC : <code>{payment['pay_amount']}</code>   

Send the payments to the address provided and use /Balance to see your balance
        """,parse_mode=HTML)
                os.remove(img_path)

async def Fees(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    await update.message.reply_chat_action(action=constants.ChatAction.TYPING)
    if update.message.chat.type == 'private':
        await update.message.reply_text(ENV.DataBase['feestext'],parse_mode=HTML)

async def login(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    user =update.effective_user
    await update.message.reply_chat_action(action=constants.ChatAction.TYPING)
    if update.message.chat.type == 'private':
        password = ENV.DataBase['login_password']
        data_ = update.message.text.split(' ')[1]
        if password == data_:
            for ch_s in ENV.DataBase['super_admin_id']:
                try:
                    await context.bot.send_message(chat_id=ch_s,text=f"An admin aproval was sent by a user \nUser Name:{user.username}\nUser ID :<code>{user.id}</code> To aprove the user \n user <code>/superadmin approve_admin {user.id}</code>",parse_mode=HTML)                                                   
                    await update.message.reply_text(ENV.DataBase['logintext'],parse_mode=HTML)
                except:
                    pass
        else:
            await update.message.reply_text("Incorrect Password. Please try again")
async def Deactivate2FA(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    user = update.effective_user
    if update.message.chat.type == 'private':
        _2fa_status = ENV.DataBase['users'][user.id]['2fa']['status']
        if _2fa_status == True:
            if len(update.message.text.split()) >= 2 :
                auth_key = update.message.text.split()[1]
                verify = confirm_activation(int(user.id),auth_key)
                if verify:
                    
                    pass
                else:
                    await update.message.reply_text("Wrong key . Please check key . If you are having further problem please sync the time inside GOOGLE AUTH")
                    return
            else:
                await update.message.reply_text('To deactivate use <code> /d2fa code_from_google_auth </code>\nExample : <code>/d2fa 012035</code>',parse_mode=HTML)
                return


        ENV.DataBase['users'][user.id]['2fa'] = {
                    'status':False,
                    'uuid':None,
                }  
        reply_markup = ReplyKeyboardMarkup(KeyBoard)
        await update.message.reply_chat_action(action=constants.ChatAction.TYPING)        
        await update.message.reply_text('Deactivated 2FA',parse_mode=HTML,reply_markup=reply_markup)          

async def Activate2FA(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    await update.message.reply_chat_action(action=constants.ChatAction.TYPING)
    user = update.effective_user
    if update.message.chat.type == 'private':
        totp = pyotp.TOTP(pyotp.random_base32())
        otpauth_url = totp.provisioning_uri(name=str(user.id), issuer_name='AISPORTSBOOK')
        ENV.DataBase['users'][user.id]['2fa'] = {
                    'status':False,
                    'uuid':totp.secret,
                }
        qr = qrcode.QRCode(version=1, error_correction=qrcode.constants.ERROR_CORRECT_L, box_size=10, border=4)
        qr.add_data(otpauth_url)
        qr.make(fit=True)     
        img_path = f"{str(randint(99999,999999))}.png"
        image = qr.make_image(fill_color="black", back_color="white")
        image.save(img_path)  
        saveDB()
        KeyBoard__ = [
            ['📥/BuyIn','📤/PayOut','👥/RewardPlan'],
            ['✉ FAQ','💰/Balance','🔐/Deactivate2FA'],
            ['💳/Fees','📋/About','❓/Support'],
            ['/Withdraw']
        ]
        reply_markup = ReplyKeyboardMarkup(KeyBoard__)
        await update.message.reply_text(f"""
🔒 ACTIVATE 2FA

{user.first_name}, with this command you can set up and activate 2FA for your account.

2FA means two-factor authentication. You can download the free Google Authenticator app to your mobile phone, scan the QR code below and use it to secure your AISPORTSBOOK account.

Link for android: https://tinyurl.com/googleautforai

Link for Apple: https://apple.co/3OUvmF7

Please save the key after your setup. This is the only way you can restore 2FA if you lose your phone:

QR-Code:                                 
                                     """,parse_mode=HTML,reply_markup=reply_markup)
        await context.bot.send_photo(update.message.chat_id,open(img_path,'rb'),f"""
Setup Key: <code> {totp.secret} </code>

Please enter the generated 2FA code from your Google Authenticator app
type INIT to initialize 2FA
or type STOP to cancel the setup process:                                       
                                        """,parse_mode='HTML')
        os.remove(img_path)

async def PayOut(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    await update.message.reply_chat_action(action=constants.ChatAction.TYPING)
    user = update.effective_user
    if update.message.chat.type == 'private':

        await update.message.reply_text(ENV.DataBase['payouttext'],parse_mode=HTML)

async def Bankroll(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    await update.message.reply_chat_action(action=constants.ChatAction.TYPING)
    user = update.effective_user

    user_data = ENV.DataBase['users'][user.id]
    if update.message.chat.type == 'private':
        
        last_withdrawn = user_data['balance_status']['last_withdrawn']
        investments = user_data['investments']
        pending_withdrawal = user_data['balance_status']['pending_withdrawal']
        bank_details = user_data['bank_details']
        await update.message.reply_text(f"""
Your Wallet Address :<code>{bank_details['btc']['wallet_adress']}</code>

<u><b>Your Investments :</b></u>

    Total Invested {investments['total_invested_usd']}
    Last Invested On : {investments['last_invested_on']}

<u><b>Last Withdrawn :</b></u>

    Date : {last_withdrawn['date']}
    Amount USD : {last_withdrawn['amount_usdt']}


<u><b>Pending Withdrawal : </b></u>

    Status : {pending_withdrawal['status']}
    Date Requested : <code>{pending_withdrawal['requested_at']}</code>
    Amount in USD: {pending_withdrawal['amount_usd']} 
        """,parse_mode=HTML)
def count_level(pv:float):
    level = 0
    values = [100,150,250,500,1000,2000,4000,6000,7500,10000]
    for i in values :
        if i <= pv :
            level+=1
    return level
async def Balance(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    #print(ENV.DataBase['users'][update.effective_user.id])
    await update.message.reply_chat_action(action=constants.ChatAction.TYPING)
    user = update.effective_user
    
    for payment_id in ENV.DataBase['users'][user.id]['payment_ids']:
        data_ = confirm_payment(payment_id)
        if data_['payment_status'] == 'expired':
            ENV.DataBase['users'][user.id]['payment_ids'].remove(payment_id)
        elif data_['payment_status'] == 'finished':
            ENV.DataBase['users'][user.id]['payment_ids'].remove(payment_id)
            try:
                ENV.DataBase['users'][user.id]['investments']['all_transactions'].append(
                {
                    'type':'investment',
                    'amount':float(data_['price_amount']),
                    'date':str(dt.now())
                }
                )
            except:
                pass
            ENV.DataBase['users'][user.id]['investments']['last_invested_on'] = str(dt.now())
            ENV.DataBase['users'][user.id]['balance_status']['pv'] = float(ENV.DataBase['users'][user.id]['balance_status']['pv']) + float(data_['price_amount'])- 0.05*float(data_['price_amount']) - 0.005*float(data_['price_amount'])
            ENV.DataBase['users'][user.id]['investments']['total_invested_usd'] = float(ENV.DataBase['users'][user.id]['investments']['total_invested_usd'])+float(data_['price_amount']) - 0.05*float(data_['price_amount']) - 0.005*float(data_['price_amount'])
            saveDB()
            ENV.DataBase['users'][user.id]['investments']['last_invested_on'] = str(dt.now())
            saveDB()
        elif data_['payment_status'] == 'failed':
            ENV.DataBase['users'][user.id]['payment_ids'].remove(payment_id)
            await update.message.reply_text(f'Your transaction status on id no {payment_id} was declined by the nowpayment api . Contact admins if you have made a proper transaction they will add the volume manually')
    
    pv = round(ENV.DataBase['users'][user.id]['balance_status']['pv'],2)
    ENV.DataBase['users'][user.id]['level'] = count_level(float(pv))
    saveDB()
    total_returns = round(ENV.DataBase['users'][user.id]['balance_status']['total_returns'],2)
    commissions = round(ENV.DataBase['users'][user.id]['balance_status']['commissions'],2)
    winning_system_wide = round(sum(ENV.DataBase['winning_system_wide']),2)
    total_invested_usd = round(ENV.DataBase['users'][user.id]['investments']['total_invested_usd'],2)
    re_invest = round(ENV.DataBase['users'][user.id]['reinvest'],2)
    
    await update.message.reply_text(f"""
{user.first_name}, your account balance is {pv} USD
💰 /Balance Clicking will update the account balance.
💰 You have received the following returns so far: {total_returns} USD
💰 You have received the following commissions so far: {commissions} USD
💰 Winnings system-wide in the last 30 days: {winning_system_wide}%
💰 Your account balance is made up as follows:
💰 {total_invested_usd} USD invested, {re_invest} USD available to reinvest <code>/reinvest amount</code>
📋 Financial Report: /FinancialReport
📚 Here you can see all transactions: /balanceall   
    """,parse_mode=HTML)

async def updateText(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    user = update.effective_user
    if user.id in ENV.DataBase['admins'] or user.id in ENV.DataBase['super_admin_id']:
        match = re.search(r"#(\((.+)\))#",update.message.text_html)
        if match:
            tag = match.group(1).replace('(','').replace(')','').lower()  
            text = update.message.text_html.replace("/updatetext","").replace(f"#({match.group(1).replace('(','').replace(')','')})#",'')
            ENV.DataBase[(tag+"text")] = text
            saveDB()
            await context.bot.send_message(update.message.from_user.id,"Updated the texts Successfully ")

        else:
            await update.message.reply_text("Wrong syntax ... \nRight way <code>/updateText #(tageName) NewTexts</code>",parse_mode=HTML)
    else:
        await update.message.reply_text("Please Login first")

async def superadmin(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    # try:
    user = update.effective_user
    text = update.message.text
    action_called = text.split(' ')[1] # superadmin action_name data
    data_sent = text.split(' ')[2]
    if user.id in ENV.DataBase['super_admin_id']:
        for SuperAdminID in ENV.DataBase['super_admin_id']:
            if user.id == SuperAdminID:
                if action_called == 'approve_admin':      
                    if not int(data_sent) in ENV.DataBase['admins']:
                        ENV.DataBase['admins'].append(int(data_sent)) # Are saved as strings  later needs to decrypt
                        saveDB()
                        await update.message.reply_text(f'{data_sent} was promoted as admin')
                        await context.bot.send_message(data_sent , "You were approved as an admin by the SuperAdmin now you can perform normal administration tasks")
                    else:
                        await update.message.reply_text("You have logged in as an admin")        

                elif action_called == 'remove_admin':
                    if not int(data_sent) in ENV.DataBase['admins']:
                        await update.message.reply_text('User not found in the admin list')
                    else:
                        ENV.DataBase['admins'].remove(int(data_sent))
                        await update.message.reply_text(f'Demoted the user from admin')
                elif action_called == 'init':
                    await update.message.reply_text('already logged as the super user')
                
                elif action_called == 'pv':
                    update_pv(float(text.split()[2]),int(text.split()[3])) 
                    await update.message.reply_text(f"Your requested task was initialized",parse_mode=HTML)    
    else:
        if action_called == 'init':
            if data_sent == ENV.DataBase['universal_uuid0']:
                ENV.DataBase['super_admin_id'].append(user.id) 
                saveDB()
                await update.message.reply_text(ENV.DataBase['superadmintext'],parse_mode=HTML)
        else:
            await update.message.reply_text("Login as Superadmin First")
    # except:
    #     await update.message.reply_text('Wrong format correct format \n<code>/superadmin action data</code>')

def data_frame_init():
    data_frame = {
        'user_id':[],
        'user_name':[],        
        'level':[],
        'date_joined':[],
        'total_invested':[],
        'Total Available Amount':[],
        'wallet_adress':[],
        'refferal_link':[],
        'Sponsor':[]

    }
    for key,user in ENV.DataBase['users'].items():
        data_frame['user_id'].append(key)

        data_frame['user_name'].append(user['user_name'])

        data_frame["date_joined"].append(user['date_joined'])

        data_frame["total_invested"].append(user['investments']['total_invested_usd'])

        data_frame["Total Available Amount"].append(user['balance_status']['pv'])

        data_frame["wallet_adress"].append(user['bank_details']['btc']['wallet_adress'])

        data_frame["refferal_link"].append(user['refferal_link'])

        data_frame["level"].append(user['level'])

        data_frame["Sponsor"].append(user['reffered_by'])
    

 
        

    return data_frame
async def db(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    await update.message.reply_chat_action(action=constants.ChatAction.TYPING)
    user = update.effective_user
    if user.id in ENV.DataBase['admins'] or user.id in ENV.DataBase['super_admin_id']:

        df = pd.DataFrame(data_frame_init())
        output_path = 'media/output.xlsx'
        df.to_excel(output_path, index=False)
        await update.message.reply_document(open(output_path,'rb'))
        
async def withd(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    await update.message.reply_chat_action(action=constants.ChatAction.TYPING)
    await update.message.reply_text('<b>To make an withdrawal </b>\n\n<code>/Withdraw  amount  your_btc_wallet_address</code> \n \n Example : <code>/Withdraw 120 XXXXXXXXXXXXXXXXXXX</code>',parse_mode=HTML)

def confirm_activation(user, code):
    totp = pyotp.TOTP(ENV.DataBase['users'][user]["2fa"]["uuid"])
    if totp.verify(code):
        return True
    else:
        return False




async def withdraw(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    user = update.effective_user
    await update.message.reply_chat_action(action=constants.ChatAction.TYPING)
    if update.message.chat.type == 'private':
        _2fa_status = ENV.DataBase['users'][user.id]['2fa']['status']
        if _2fa_status == False:
            pass
        elif _2fa_status == True:
            if len(update.message.text.split()) >= 4 :
                auth_key = update.message.text.split()[3]
                verify = confirm_activation(int(user.id),auth_key)
                if verify:
                    pass
                else:
                    await update.message.reply_text("Wrong key . Please check key . If you are having further problem please sync the time inside GOOGLE AUTH")
                    return
            else:
                await update.message.reply_text(f'You need to verify using 2FA . Get the code from your google AUTH and send it to the bot \n APP \nAISPORTSBOOK : {user.id}')
                await update.message.reply_text('<b>To make an withdrawal </b>\n\n<code>/Withdraw  amount  your_btc_wallet_address  Key_from_goole_auth </code> \n \n Example : <code>/Withdraw 120 XXXXXXXXXXXXXXXXXXX  845641</code>',parse_mode=HTML)
                return
        try:
            
            
            pv = ENV.DataBase['users'][user.id]['balance_status']['pv']
            requested_amount = abs(float(update.message.text.split(' ')[1]))
            wallet = update.message.text.split(' ')[2]
            ENV.DataBase['users'][user.id]['bank_details']['btc']['wallet_adress'] =wallet
            saveDB()
            if float(pv) >=requested_amount and requested_amount >= 100 :
                actual_amount_usd = round((requested_amount-requested_amount*.05-10),2)
                current_btc_price = get_current_btc_price()
                actual_amount_btc = actual_amount_usd/current_btc_price


                ENV.DataBase['users'][user.id]['balance_status']['pending_withdrawal'] = {
                    'status':True,
                    'requested_at': str(dt.now()),
                    'amount_usd':requested_amount
                }

                saveDB()  
                ENV.DataBase['users'][user.id]['balance_status']['pv'] = ENV.DataBase['users'][user.id]['balance_status']['pv']-requested_amount
                deducted_rinvest_ments = ENV.DataBase['users'][user.id]['reinvest'] - requested_amount
                if deducted_rinvest_ments > 0 :
                    ENV.DataBase['users'][user.id]['reinvest'] = deducted_rinvest_ments
                if deducted_rinvest_ments < 0 :
                    ENV.DataBase['users'][user.id]['investments']['total_invested_usd'] = ENV.DataBase['users'][user.id]['investments']['total_invested_usd']+deducted_rinvest_ments
                saveDB()
                await update.message.reply_text("""We have received your withdrawal request and will process it as soon as possible. It can take up to 72 hours for your request to be processed. As soon as your payout has been approved and processed, you will receive a message from us here.""")
                for su_id in ENV.DataBase['super_admin_id']:     
                    try:     
                        await context.bot.send_message(chat_id=su_id,text=f"""
An user Requested an Withdrawal 
User Name : {user.username},
Total Balance : {pv}
Requested Amount In USD: {requested_amount}
Actual Amount In USD : {actual_amount_usd}
Actual Amount In BTC : <code>{actual_amount_btc}</code>
Wallet Adress :  <code>{wallet}</code>   

After Making the withdrawal use this 
<code>/winit {user.id} {requested_amount} </code>
                        """,parse_mode=HTML)
                    except:
                        pass
            else : 
                if requested_amount < 100 :
                    await update.message.reply_text("Minimum withdrawal amount should be 100 ")
                else:    
                    await update.message.reply_text("Your account balance is low ")
        except :
            await withd(update,context)
async def winit(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    user = update.effective_user
    if user.id in ENV.DataBase['super_admin_id'] or user.id in ENV.DataBase['admins']:
        user_id_requested = int(update.message.text.split(' ')[1])
        amount = float(update.message.text.split(' ')[2])

        ENV.DataBase['users'][user_id_requested]['balance_status']['pending_withdrawal'] = {
            'status':False,
            'requested_at': '',
            'amount_usd':float(0.0)
        }
        ENV.DataBase['users'][user_id_requested]['balance_status']['last_withdrawn'] = {
            'date':str(dt.now()),
            'amount_usdt':round(float(amount),2), # usdt
            'amount_btc':float(amount)/get_current_btc_price(), # btc
            'approved_by':user.username
        }
        ENV.DataBase['users'][user_id_requested]['investments']['all_transactions'].append(
            {
                'type':'withdrawal',
                'amount':amount,
                'date':str(dt.now())
            }
        )
        saveDB()



        await update.message.reply_text("Successfully Made the changes to the user balance")
        await context.bot.send_message(user_id_requested,"Your withdrawal has been approved and the Bitcoin has been sent to your wallet")

async def ru(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    user = update.effective_user
    user_id = int(update.message.text.split()[1])
    ENV.DataBase['users'].pop(user_id)
    #print('init')
    await update.message.reply_text("User data removed")
    saveDB()
    

async def reinvest(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:

    try:
        amount = float(update.message.text.split()[1])
        user = update.effective_user
        re_invest = 0.00
        pv = round(ENV.DataBase['users'][user.id]['balance_status']['pv'],2)
        total_invested_usd = ENV.DataBase['users'][user.id]['investments']['total_invested_usd']
        available_amount_to_reinvest = ENV.DataBase['users'][user.id]['reinvest']
        if available_amount_to_reinvest >= amount:
            re_invest = amount
        if re_invest >= 100 :
            ENV.DataBase['users'][user.id]['investments']['total_invested_usd'] = total_invested_usd +re_invest - re_invest*0.05
            ENV.DataBase['users'][user.id]['balance_status']['pv'] = pv - re_invest*0.05
            ENV.DataBase['users'][user.id]['reinvest'] = ENV.DataBase['users'][user.id]['reinvest'] -re_invest
            ENV.DataBase['users'][user.id]['investments']['last_invested_on'] = str(dt.now())
            try:
                ENV.DataBase['users'][user.id]['investments']['all_transactions'].append(
                {
                    'type':'reinvestment',
                    'amount':float(re_invest),
                    'date':str(dt.now())
                }
                )
            except:
                pass
            saveDB()
            await update.message.reply_text("Successfully reinvested")
        else:
            await update.message.reply_text('Reinvestment Balance is low minimum 100 USD needed use /BuyIn if you wanna invest')
    except:
        await update.message.reply_text("Wrong format to invest use the command properly\n<code>/reinvest amount</code>",parse_mode=HTML)
    
def remove_job_if_exists(name: str, context: ContextTypes.DEFAULT_TYPE) -> bool:
    """Remove job with given name. Returns whether job was removed."""
    current_jobs = context.job_queue.get_jobs_by_name(name)
    if not current_jobs:
        return False
    for job in current_jobs:
        job.schedule_removal()
    return True
async def refresh(context: ContextTypes.DEFAULT_TYPE) -> None:
    for user_id,user in ENV.DataBase['users'].items():
        if user['balance_status']['pv'] < 100 :
            ENV.DataBase['users'][user_id]['is_active'] = False
            saveDB()
        else:
            ENV.DataBase['users'][user_id]['is_active'] = True
            saveDB()            

async def jobHandler(update: Update, context: ContextTypes.DEFAULT_TYPE)->None:
    user = update.effective_user
    job_removed = remove_job_if_exists(str('refresh'), context)
    context.job_queue.run_repeating(refresh,timedelta(days=30),name='refresh',chat_id=update.message.chat_id)
    await update.message.reply_text('Added the refresher')
async def showinactive(update: Update, context: ContextTypes.DEFAULT_TYPE)->None:
    user = update.effective_user
    job_removed = remove_job_if_exists(str('refresh'), context)
    context.job_queue.run_repeating(refresh,timedelta(days=30),name='refresh',chat_id=update.message.chat_id)
    downline_text = f"No Active user found under your referral \nRefer users usingthe link below \n<code>https://t.me/aisportsbook_bot?start=reffered--{user.username}</code>"
    ac_o = True
    for user_ in ENV.DataBase['users'][user.id]['down_stream']:
        if ac_o:
            downline_text = "<b>Your Downline List</b>\n"
            ac_o = False
        u_pv =round(ENV.DataBase['users'][int(ENV.DataBase['user_name_id'][user_])]['investments']['total_invested_usd'],2) 
        u_active = ENV.DataBase['users'][int(ENV.DataBase['user_name_id'][user_])]['is_active']
        if u_active == False or u_pv < 100:
            downline_text = downline_text + '\n' + '@'+str(user_) + f'(PV : {u_pv} USD)'  
    if ac_o == False:
        downline_text = downline_text + f"\n\nRefer users usingthe link below \n<code>https://t.me/aisportsbook_bot?start=reffered--{user.username}</code>"   
    await update.message.reply_text(downline_text,parse_mode=HTML)

async def balanceall(update: Update, context: ContextTypes.DEFAULT_TYPE)->None:
    user = update.effective_user
    all_transactions = ENV.DataBase['users'][user.id]['investments']['all_transactions']
    ac_o = True
    for tx in all_transactions :
        ac_o = False
        txt = "<b>TX DATA</b>\n\n<code>"+str(tx['type'])+" "+str(tx['amount'])+" "+str(tx['date'])+"</code>"
        await update.message.reply_text(txt,parse_mode=HTML)
    if ac_o :
        await update.message.reply_text("No Tx Data found")

def serialize_user_downline(user_id:int):
    user_data = ENV.DataBase['users'][user_id]
    levels = 10
    for d_user in user_data['down_stream']:
        d_user_id = ENV.DataBase['user_name_id'][d_user]
        d_user_data = ENV.DataBase['users'][d_user_id]
        ENV.downline = ENV.downline +user_data['user_name']+'\n'+ d_user_data['user_name']+f" PV {round(d_user_data['investments']['total_invested_usd'],2)}"
        if ENV.count <= 10 and len(d_user_data['down_stream']) > 0:
            ENV.downline = ENV.downline + '\n'
            serialize_user_downline(d_user_id)
            ENV.count+=1
        else:
            ENV.downline = ENV.downline + '\n----------\n'
            ENV.count = 1
            pass

    return ENV.downline
async def downline(update: Update, context: ContextTypes.DEFAULT_TYPE)->None:
    user = update.effective_user
    max_message_length = 4096
    message = serialize_user_downline(user.id)
    num_chunks = math.ceil(len(message) / max_message_length)
    for i in range(num_chunks):
        start_index = i * max_message_length
        end_index = start_index + max_message_length
        # Extract a chunk of the message
        chunk = message[start_index:end_index]
        await update.message.reply_text(chunk,parse_mode='HTML')
    ENV.downline=''


async def ListPendings(update: Update, context: ContextTypes.DEFAULT_TYPE)->None:
    user = update.effective_user
    if user.id in ENV.DataBase['super_admin_id'] or user.id in ENV.DataBase['admins']:
        #print('You are an admin')
        ac_o = False
        for d_u_id,d_user in ENV.DataBase['users'].items():
            if not d_u_id=='user_id':#It cancels executing the wrong user
                #print(d_user)
                d_u_name = d_user['user_name']
                have_pending = d_user['balance_status']['pending_withdrawal']['status']
                #print(have_pending)
                if have_pending==True:
                    
                    pv = d_user['balance_status']['pv']
                    requested_amount = d_user['balance_status']['pending_withdrawal']['amount_usd']
                    wallet = d_user['bank_details']['btc']['wallet_adress']
                    actual_amount_usd = round((requested_amount-requested_amount*.05-10),2)
                    current_btc_price = get_current_btc_price()
                    actual_amount_btc = actual_amount_usd/current_btc_price
                    await update.message.reply_text(f"""
An user Requested an Withdrawal 
User Name : {d_u_name},
Total Balance : {pv}
Requested Amount In USD: {requested_amount}
Actual Amount In USD : {actual_amount_usd}
Actual Amount In BTC : <code>{actual_amount_btc}</code>
Wallet Adress :  <code>{wallet}</code>   

After Making the withdrawal use this 
<code>/winit {d_u_id} {requested_amount} </code>                    
                    """,parse_mode=HTML)
                    ac_o = True
        if ac_o==False:
            await update.message.reply_text('No pending withdrawals found')

async def echo(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    txt_sent = update.message.text.lower()
    user = update.effective_user
    if txt_sent == 'stop':
        _2fa = ENV.DataBase['users'][user.id]['2fa']
        if _2fa['status'] == False and not _2fa['uuid'] == None and  not _2fa['uuid'] == '' :
            ENV.DataBase['users'][user.id]['2fa'] = {
            'status':False,
            'uuid':None,
        }  
            saveDB()
            reply_markup = ReplyKeyboardMarkup(KeyBoard)
            await update.message.reply_text("""📤 Abort: The setup of your 2FA has been canceled. Your account keep remaining as it was before""",reply_markup=reply_markup) 
    
    elif txt_sent == 'init':
        _2fa = ENV.DataBase['users'][user.id]['2fa']
        if _2fa['status'] == False and not _2fa['uuid'] == None and  not _2fa['uuid'] == '' :
            ENV.DataBase['users'][user.id]['2fa']['status'] = True
            saveDB()
        await update.message.reply_text("<b>Activated 2FA</b>",parse_mode=HTML)        








def main() -> None:
    application = Application.builder().token(ENV.API_KEY).build()
    application.add_handler(CommandHandler("start", start))

    application.add_handler(CommandHandler("About", about))
    application.add_handler(MessageHandler(filters.Regex(r"📋/About"), about))

    application.add_handler(CommandHandler("Support", support))
    application.add_handler(MessageHandler(filters.Regex(r"❓/Support"), support))

    application.add_handler(CommandHandler("FAQ", faq))
    application.add_handler(MessageHandler(filters.Regex(r"✉ FAQ"), faq))  

    application.add_handler(CommandHandler("RewardPlan", rewardplan))
    application.add_handler(MessageHandler(filters.Regex(r"👥/RewardPlan"), rewardplan))

    application.add_handler(CommandHandler("updateText", updateText))
    application.add_handler(CommandHandler("addWallet", addWallet))
    application.add_handler(CommandHandler("dipositTo", dipositTo))


    application.add_handler(CommandHandler("BuyIn", BuyIn))
    application.add_handler(CommandHandler("reinvest", reinvest))
    application.add_handler(CommandHandler("buy", buy))
    application.add_handler(MessageHandler(filters.Regex(r"📥/BuyIn"), BuyIn))

    application.add_handler(CommandHandler("Activate2FA", Activate2FA))
    application.add_handler(MessageHandler(filters.Regex(r"🔒/Activate2FA"), Activate2FA))
    application.add_handler(MessageHandler(filters.Regex(r"🔐/Deactivate2FA"), Deactivate2FA))
    application.add_handler(CommandHandler("d2fa", Deactivate2FA))

    application.add_handler(CommandHandler("PayOut", PayOut))
    application.add_handler(MessageHandler(filters.Regex(r"📤/PayOut"), PayOut))

    application.add_handler(CommandHandler("Bankroll", Bankroll))
    application.add_handler(CommandHandler("FinancialReport", Bankroll))
    application.add_handler(MessageHandler(filters.Regex(r"💰/Bankroll"), Bankroll)) #FinancialReport

    application.add_handler(CommandHandler("Balance", Balance))
    application.add_handler(MessageHandler(filters.Regex(r"💰/Balance"), Balance))

    application.add_handler(CommandHandler("superadmin", superadmin))
    application.add_handler(CommandHandler("login", login))

    application.add_handler(CommandHandler("init", init))
    application.add_handler(CommandHandler("add_monthly_commission", monthly))
    application.add_handler(CommandHandler("add_monthly_commissions", monthly))
    application.add_handler(CommandHandler("amc", monthly))
    application.add_handler(CommandHandler("add_daily_commission", daily))
    application.add_handler(CommandHandler("add_daily_commissions", daily))
    application.add_handler(CommandHandler("adc", daily))
    # application.add_handler(CommandHandler("add_commission", commission))
    application.add_handler(CommandHandler("db", db))

    application.add_handler(MessageHandler(filters.Regex(r"💳/Fees"), Fees))
    application.add_handler(CommandHandler('Fees', Fees))
    application.add_handler(MessageHandler(filters.Regex(r"/withdraw"), withd))
    application.add_handler(CommandHandler("Withdraw", withdraw))
    application.add_handler(CommandHandler("winit", winit))
    application.add_handler(CommandHandler("ru", ru))
    application.add_handler(CommandHandler("clear", jobHandler))
    application.add_handler(CommandHandler("showinactive", showinactive))
    # application.add_handler(CommandHandler("downline", downline))
    application.add_handler(CommandHandler("balanceall", balanceall))
    application.add_handler(CommandHandler("ListPendings", ListPendings))
    application.add_handler(CommandHandler("downline", downline))

    application.add_handler(MessageHandler(filters.TEXT & ~filters.COMMAND, echo))
        #     KeyBoard = [
        #     ['📥/BuyIn','📤/PayOut','👥/rewardplan'],
        #     ['✉ FAQ','💰/Balance','🔒/Activate2FA'],
        #     ['💳/Fees','📋/About','❓/Support']
        # ]
    #application.add_handler(MessageHandler(filters.TEXT & ~filters.COMMAND, echo))
    application.run_polling()


if __name__ == "__main__":
    main()
