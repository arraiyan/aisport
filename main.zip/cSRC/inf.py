from .text import *

class env:
    API_KEY = "6122531402:AAFb8xLQ7qAMIEWdPAXfRdIdxKzreLJUtyM"
    downline = ""
    # MESSAGES 
    count = 1
    DataBase = {
        'logintext':logintext,
        'starttext' : starttext,
        'feestext':feestext,
        'abouttext' : abouttext,
        'supporttext': supporttext ,
        'faqtext'   :faqtext,
        'rewardplantext' : rewardplantext,
        'addwallettext': addwallettext,
        'buyintext':buyintext,
        'payouttext':payouttext,
        'superadmintext':superadmintext,
        'dipositaddress':str("none"),
        'super_admin_id':[], #user id
        'login_password': '1234',
        'admins':[],
        'daily_commission':0.0,
        'daily_commission_security_key':str(),
        'commission':0.0,
        'commission_security_key':str(),
        'monthly_commission':0.0,
        'monthly_commission_security_key':str(),
        'universal_uuid0':'7624be35-644d-49d9-9449-b5262a8623ab',
        'winning_system_wide':[],
        'user_name_id':{},
        'users':{
            'reinvest':float(0.00),
            'user_id':{
                'is_active':True,
                'down_stream':[],
                'level':0,
                '2fa':{
                    'status':False,
                    'uuid':str(),
                },
                'user_name':""  , 'rank' : int() ,"reffered_by":"referrer_id","sponsore_id":"sponsore_user_id","balance_in_btc":float(),"blance_in_usdt":float(),
                'date_joined':"date" , "balance_status":{
                    'pv':0.00,
                    'daily_bonus':0.00,
                    'total_returns':0.00,
                    'commissions':0.00,
                    'last_withdrawn':{
                        
                        'date':'date',
                        'amount_usdt':float(0.00), # usdt
                        'amount_btc':float(0.00000), # btc
                        'approved_by':'admin_user_name'
                    },
                    'pending_withdrawal':{

                        'status':False,#when withdrawn it should be true 
                        'requested_at':'date',
                        'amount_usd':float(0.00),
                        
                        
                    }
                },
                'bank_details':{
                    'btc':{
                        'wallet_adress':str(),
                    }
                },
                'investments':{
                    'total_invested_usd':0.00,
                    'last_invested_on':'date',
                    'all_transactions':[]
                },
                'refferal_link':str() ,
                'payment_ids':[],
            },
        },

    }

    