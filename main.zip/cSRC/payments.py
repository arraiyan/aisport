import requests
from nowpayments import NOWPayments as npay
from datetime import timedelta
payment_api_key = 'HKS63P2-8PD400F-HTFDCK1-G3W9CS8'

def new_payment(price_amount:float):
    pay = npay(payment_api_key)
    new_pay = pay.create_payment(price_amount,price_currency='usd',pay_currency='btc')
    return new_pay
def confirm_payment(payment_id):
    try: 
        pay = npay(payment_api_key)
        status = pay.get_payment_status(payment_id=payment_id)
        return status
    except:
        return {'payment_status':'failed'}
def minimum_amount():
    pay = npay(payment_api_key)
    amount = pay.get_minimum_payment_amount('btc','btc','usd')
    return amount
def get_current_btc_price():
    response = requests.get('https://api.coindesk.com/v1/bpi/currentprice.json')
    data = response.json()
    value = float(data["bpi"]["USD"]["rate"].replace(',',''))
    return value

