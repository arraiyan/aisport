
starttext = f"""Herzlich Willkommen bei AISPORTSBOOK!
💰 The sports betting app for Telegram, which credits daily winnings to your wallet.
🏉 Earnings are generated through strategic sport betting all over the world.
💲 Thewinnings achieved in the last few months have been between 0.0% and 1.5% per day. (7 days a
week). The processing from deposit to withdrawal is fully automated and thus ensures a smooth
process.
🏦 Deposits and withdrawals are made in BTC. After the deposit, the BTC are exchanged into USDT at
the current daily rate, as this is used as the basic means of payment for the various bets we place.
📥 Now create your AISPORTSBOOK and click on /BuyIn . You can then transfer your first BTC and benefit
from the daily winnings.
"""
abouttext = """
🔔 Welcome at AISPORTSBOOK, the sports betting community
🏀 Let's be honest. You ended up here because you keep losing money betting or you were looking for a way to
make money. Correct? We realized that if we want to continue our passion with sports betting, we had to find a
solution. We approached the whole thing professionally from that moment on. Based on countless tests,
evaluations and constant exchange of experience with profitable sports bettors, we have developed our own
system. We do not promise that we will not lose any more bets, because that would simply be a lousy lie. Losing
is part of sports betting, the important thing is that you win more than you lose!
✅ Most people think that sports betting is about finding ‘sure things,’ but in reality such ‘locks’ are nothing more
than gamblers’ fancy. Just as in real estate, currency, stocks, crypto or any other speculative market, ‘sure things’
simply do not exist. As professional sports bettors , our goal is to find and exploit many small edges over a long
period of time to earn a compounding return. Winning 55% of games is very significant, and with very
conservative bet sizing, you can grow your return very quickly. Investing $10,000 into the stock market for a year
and earning a 10% return is considered a great investment – but your return winning a modest 54% of your
sports bets would trounce that return. AISPORTSBOOK is the right choice for anyone who wants to invest and
perhaps set up their own investor team, without the headache of daily bets and picks. One more thing:
AISPORTSBOOK is no guarantee, no promise, no investment advice. It is a community in which opportunity-oriented
sports betting enthusiasts are sought, bought and held for the best possible winnings.
With this in mind,
Welcome,
Your AISPORTSBOOK team
"""
supporttext = """
❓Support at AISPORTSBOOK
📌 If you have any questions or support regarding the AISPORTSBOOK, please contact your sponsor. Your sponsor is
󰞵 “Rank” John Doe - @username
✉ If your sponsor cannot answer your questions, you can also contact our support via email with subject
account number #accountnumber_from_telegram_bot - support@domain.com
"""
faqtext = """
💡 How does AISPORTSBOOK work?
📥 /BuyIn
Transfer bitcoins worth between 100.00 USD and 100,000.00 USD to your displayed wallet address in the bot.
You will receive a share of between 0.0% and 1.5% daily (Monday to Sunday) based on the deposited and
reinvested amounts.
📤 /PayOut
To make a withdrawal, click on the withdrawal button and follow the instructions. You can withdraw your winnings
in BTC. A payout is possible at any time. As a rule, the payout is carried out within 24 hours. In the event of
strong price fluctuations on the market, the payout can be extended to up to 72 hours.
💰 /Bankroll
Shows you your account balance and payments made to your wallet. It also shows all your transactions, payouts
and daily profits.
👥 /rewardplan
Shows you the number of your partners, your team turnover and your team commissions. Here you will also find
your referral link to invite your partners/friends.
❓ /Support
If you have any questions about the AISPORTSBOOK, talk to your sponsor. He will familiarize you with all the
conditions in the bot.
🔒 /Activate2FA
You can make your account more secure by enabling 2FA.
🪪 /ActivateKYC
No KYC needed
💳 Fees
There is a 5% fee for deposits, follow-up payments, reinvest and withdrawals. In addition, there are 10 USD
transfer fees for withdrawals
"""


rewardplantext = """
AISPORTSBOOK
offers a reward plan that allows you to earn commissions by building your network.
📥 /BuyIn
To be activated for the Reward Plan, please first deposit a minimum amount of 100 USD. Your sponsor link will
then be displayed at this point.
👥 Reward Plan
If you recommend AISPORTSBOOK, you will receive the following commissions:
30% based on the daily reported income is distributed up to 10 levels deep.
01st level - 10% (minimum deposit 100 USD)
02nd level - 5.0% (minimum deposit 150 USD)
03rd level - 2.5% (minimum deposit $250)
04th level - 2.5% (minimum deposit 500 USD)
05th level - 2.5% (minimum deposit $1,000)
06th level - 2.5% (minimum deposit $2,000)
07th Level - 2.0% (minimum deposit $4,000)
08th Level - 1.0% (minimum deposit $6,000)
09th Level - 1.0% (minimum deposit $7,500)
10th level - 1.0% (minimum deposit $10,000)
There is also a lifestyle bonus:
🥉Bronze one-time 250 USD bonus (min. 5 direct members with a total of 5,000.00 USD own turnover)
🥈Silver monthly 500 USD bonus (min. 5 direct bronze + 25,000.00 USD team volume)🥇
🥇Gold monthly 2,000 USD bonus (min. 5 direct Silver + 150,000.00 USD team volume)
󰥔 Onyx monthly 10,000 USD bonus (min. 5 direct gold + 1,000,000.00 USD team volume)
🦪Pearl monthly $20,000 bonus (min. 5 direct Onyx + $5,000,000.00 team volume)
💎Diamond monthly $30,000 bonus (min. 5 direct Pearl + $25,000,000.00 team volume)
🎯Ammolite monthly $50,000 bonus (min. 5 direct Diamonds + $100,000,000.00 team volume)
"""


addwallettext = "Added Successfully"
buyintext = """
Transfer bitcoins worth between 100.00 USD and 100,000.00 USD to your displayed wallet address in the bot.
You will receive a share of between 0.0% and 1.5% daily (Monday to Sunday) based on the deposited and
reinvested amounts.
Scan the QR code below to make payments
"""

payouttext = """
To make a withdrawal, click on the withdrawal button and follow the instructions. You can withdraw your winnings
in BTC. A payout is possible at any time. As a rule, the payout is carried out within 24 hours. In the event of
strong price fluctuations on the market, the payout can be extended to up to 72 hours
"""

superadmintext = """
Congrats You are the New super admin
You can perform any task as you like 
"""
feestext = """
There is a 5% \fee for deposits, follow-up payments, reinvest and withdrawals. In addition, there are 10 USD
transfer fees for withdrawals.
"""
logintext="""
An admin approval request was sent to the SuperAdmin
"""