import pickle
from .inf import env as ENV
def saveDB():
    with open('db1.sqlite3','wb') as db:
        pickle.dump(ENV.DataBase,db)
        db.close()
def loadDB():
    ENV.DataBase = pickle.load(open('db1.sqlite3','rb'))
def resetDB():
    ENV.DataBase['Groups'] = []
    saveDB() 

